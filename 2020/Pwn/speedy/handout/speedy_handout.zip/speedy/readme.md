**Speedy** 

# Building

```sh
git clone https://github.com/WebKit/webkit.git WebKit
cd WebKit
git checkout 1d575a435f78ddde1c4c503be40bd1fd8d79da96
patch -p1 < release.diff
Tools/Scripts/build-webkit --jsc-only --debug
cd WebKitBuild/Debug/bin

./jsc --useConcurrentJIT=false

```

# What is this patch about ?

This patch adds a new B3 optimization pass. The working of this optimization is
as explained here in case someone does not feel like reversing that from the
code ;)

Consider a pseudo code sample like 

```js
function test(a,b){
    let d = a+1; 
    if (b > 0){        // BB1
    
        if ( d > 5 )   // BB2
            <bailout>;
    }else{
        if ( d > 5 )   // BB3
            <bailout>;
    }
    
    if ( d > 5 )       // BB4
        <bailout>;
    
    return d+b+a;
}

```

The control flow graph would be something like -

```
         BB1
          |
       -------
       |     |
       BB2  BB3
       |     |
       -------
          |
         BB4
```

It is clear that if we reach BasicBlock 4 (BB4) then `d` is less than or equal
to 5 and it will not bail out in BB4. Thus the bailout in BB4 can be eliminated.
This is what this optimization does.

The optimization first goes through the left branch and analyzes the
instructions in that block. Then it goes through the right block (BB3 in the
above eg) and if it sees a instruction common to the left branch, it keeps track
of this instruction. Finally it goes through the target branch of the if
conditions (BB4) and checks if an instruction here was present in the left and
the right branch. If it was, and if the return `type` of the instruction is
`Void` then it eliminates this instruction. The return type has to be Void
because if the return value of this instruction was used in some other place
then we don't know which value to replace this with (the one in the left branch
or the one in the right). (hmm, I see that all the guards and bounds check have
void type, but this optimization is safe right ???? )

**Note:** 
- For increased reliability, run jsc with the `--useConcurrentJIT=false` flag.
  The sesrver also runs jsc with this flag.
- For debug logs, run `./jsc --useConcurrentJIT=false
  --dumpB3GraphAtEachPhase=true <your_file>`. This optimization will emit some
  debug info which will be prepended by `ChallOpt`.

# Structure ID Leak

If you feel the need to leak the structure ID of an object for your exploit,
then it is provided by the patch. Just do `Reflect.strid(<leak_obj>)`.

# Server

Once you have a working exploit, run `/readflag` on the server to get the flag.


